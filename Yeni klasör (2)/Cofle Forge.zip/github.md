repo: Judeless/uretim-takip
branch: main

## Last sync
date: 2026-07-30T06:48:19Z

### Updated in this project
- Added EN deck slide 6 "Signal Analysis", built from `page-sinyal-analizi` in templates/dashboard_v2.html: filter strip (Department/Device/Station/Date + Load Analysis), the six .sa-stat cards (Total pulses / Mean gap / Median / Mode / Longest gap / Shortest gap), the Pulse Intervals scatter (per-pulse dots + hourly-mean line + shaded downtime bands, redrawn as inline SVG since the live one is a Chart.js canvas), the 🛡️ Signal Quality & Counting Decisions table (Counted / Noise / Early / Lost / Signal) with its "how to read" legend, and Hourly Production Pulse.
- Slide eyebrows renumbered: Gains 07, Cost Position 08, Roadmap 09, Next Steps 10.
- Slide 8 gained the in-house IoT device band: our own ESP32 counting unit at €25/station vs ≈€800 for a comparable commercial unit (1/32 cost, €6.2k avoided at 8 stations).


## Screen map
| Project screen | Repo source |
| --- | --- |
| Cofle Forge Logo v4 — 01 lockup, 04 palette, 05 type | templates/panel_giris.html (`:root` tokens, Segoe UI stack) |
| Cofle Forge Logo v4 — 03 login card | templates/panel_giris.html (`.giris-kart`, `.btn-giris`, `.alan`) |
| Cofle Forge Logo v4 — 03 sidebar header | templates/dashboard_v3.html (`.sidebar-logo`, `/logo` img at 44px) |
| Cofle Forge Logo v4 — 03 andon header | templates/andon.html (`--bg-primary`, `--border`, `--accent-*`), templates/andon_metal.html |
| Prior versions (v1–v3) | static/logo.svg (existing circular "C" fallback mark, superseded) |
| Executive Deck EN — 03 dashboard | templates/dashboard_v2.html (`:root` light tokens, .fab-toplam/.ft-hero, .bolum-kart/.bk-*, miniOeeHalka 270° yay, BOLUMLER renkleri, topbar + filtre-serit) |
| Executive Deck EN — 04 operator | templates/mobile_v2.html (screen-C: .vardiya-banner/.vb-oee, .kayit-item/.ki-*, 📡 sayaç badge, bottom .bm-tab) |
| Executive Deck EN — 06 signal analysis | templates/dashboard_v2.html (`#page-sinyal-analizi`: .ky-filtre, #sa-ozet/.sa-stat, #sa-chart Pulse Aralıkları, #sk-tablo Sinyal Kalitesi & Sayım Kararları, #sa-saatlik) |
| Executive Deck EN — 05 andon | templates/andon_v5.html (.topbar/.clock-time/.pill, .rcard active/warning/alert, .station-header st1/st2, .ref-row, .durus-row, .rt-pill, .ticker) |
| AI Sunum TR — screen mockup slide (STILL DARK — needs same fix) | templates/dashboard.html (eski/legacy) |
| Cofle Forge UI Redesign v2 (light) — all pages | templates/dashboard.html (`[data-theme="light"]` :root vars, kpi-card, inner-tab-bar, bolum-toggle, filter-bar, table-card), templates/mobile_v2.html |
| Cofle Forge UI Redesign — dashboard frame | templates/dashboard.html (kpi-card, inner-tab-btn, oee-bar, sidebar-logo, saatlik nabız) |
| Cofle Forge UI Redesign — operator frame | templates/mobile_v2.html (operator-bar, sayaç/OK adet, referans & duruş akışı) |
| Handoff package | static/logo*.png, app.py /logo endpoint |

## Sync history

## Last sync
date: 2026-07-30T05:52:00Z

### Updated in this project
- CORRECTION: live screens come from **dashboard_v2.html** (route `/dashboard`) and **mobile_v2.html** (route `/`), NOT dashboard.html (that is `/dashboard_eski`). Both are now the LIGHT "serin nötr açık tema" (#ECECF1 zemin, #FFFFFF kart, --primary #6D28D9, --brand #7C3AED, Segoe UI). Live andon is **andon_v5.html** (route `/andon`) and stays dark (#060414, cyan/violet/pink).
- EN deck slides 3–5 rebuilt on those real screens: Fabrika Özeti (fab-toplam şeridi + 6 bölüm kartı with mini OEE halkası, mini bar grafik, 3 metrik, operatör rozetleri, TK2/TK1 + TR/EN/IT), operator app screen C (vardiya banner + anlık OEE, 📡 sayaç badge, 10dk sinyal-yok uyarısı, kayıt listesi, bottom menu), andon_v5 (rcard İstasyon 1/2 + çevrim bandı + duruş paneli, Referans Takip pills, duyuru ticker).
- EN deck slides 2, 6, 8 (Starting Point / Gains / Roadmap) enriched with real graphics: before-lag timeline, before→now bar pairs + OEE gap bar, phase track + 3/8 sensor rollout meter.


## Last sync
date: 2026-07-30T04:19:54Z

### Updated in this project
- Deck screen mockups (EN slides 3–4, TR slide 5) rebuilt to match the LIVE "Komuta Merkezi" dark theme read from dashboard.html `:root` (#0c0a22 bg, glass cards rgba(255,255,255,0.06), --primary #a78bfa, grad-violet, mono values) — replacing the unimplemented v3 light redesign visuals.
- EN roadmap item "Redesigned light UI rollout (v3)" → "Per-section drill-down dashboards" (v3 redesign shelved; current design stays).
- Light-theme page-by-page redesign (`Cofle Forge UI Redesign v2 Acik Tema.dc.html`): 01 Genel Bakış, 02 Üretim, 03 Duruşlar, 04 Vardiyalar, 05–06 Operatör, 07 stil rehberi — built on the live `[data-theme=light]` tokens (#ece9f9 bg, #6366f1 primary, Inter + JetBrains Mono) read from dashboard.html.
- UI redesign proposal for dashboard Özet + operator screen (`Cofle Forge UI Redesign.dc.html`) grounded in dashboard.html KPI/tab/OEE-bar structure and mobile_v2.html shift/counter flow.
- Noted repo already renamed sidebar brand to "Cofle Forge" (dashboard.html:3870).
- Logo v4 rebuilt on the app's real palette (`#8b5cf6 → #a78bfa`, `#060414` / `#14122e` / `#2a2850`) read from `templates/panel_giris.html :root`.
- New mark direction: open segmented ring + forged core square (anvil/ECG concept dropped).
- Lockup shown in the app's actual placements: login card, dashboard sidebar header, andon header (navy `#060e1f` tokens).
- Andon variant uses one-colour white silhouette + cyan `#67e8f9` segment for long-distance legibility.
