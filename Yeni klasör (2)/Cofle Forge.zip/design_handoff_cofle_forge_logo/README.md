# Handoff: Cofle Forge Logo → uretim-takip entegrasyonu

## Overview
"Cofle Manage" olarak çalışan üretim takip uygulaması **Cofle Forge** adını alıyor.
Bu paket seçilen logoyu (plaka-F + sinyal atışı + veri düğümü) ve uygulamaya
entegrasyon talimatını içerir. Hedef repo: **Judeless/uretim-takip** (branch: main).

## About the Design Files
Bu klasördeki `Logo Export.dc.html` ve kök projedeki `Cofle Forge Logo.dc.html`
**HTML olarak hazırlanmış tasarım referanslarıdır** — üretim kodu değildir.
Görev: aşağıdaki asset'leri repoya yerleştirmek ve marka adını güncellemek.
Asset'ler hazır olduğu için UI'yi yeniden kodlamak GEREKMEZ; uygulama logoyu
zaten `/logo` endpoint'inden `<img>` ile yükler.

## Fidelity
**High-fidelity.** PNG/SVG dosyaları nihai renk ve tipografiyle üretilmiştir; birebir kullanın.

## Assets (bu paketteki `static/` klasörü)
| Dosya | Kullanım | Boyut |
| --- | --- | --- |
| `static/logo_koyu.png` | Koyu tema lockup (`/logo?tema=koyu`) | 1600×480, şeffaf zemin |
| `static/logo.png` | Açık tema lockup (`/logo`) | 1600×480, şeffaf zemin |
| `static/logo_mark.png` | Sembol tek başına — favicon kaynağı | 512×512, şeffaf zemin |
| `static/pwa_icon.png` | PWA / uygulama ikonu (koyu yuvarlatılmış kutu) | 512×512 |
| `static/logo.svg` | `/logo` son çare vektör fallback (200×60, metinli) | vektör |
| `static/logo_mark.svg` | Sembolün vektör kaynağı | vektör |

## Entegrasyon adımları
1. **Dosyaları değiştir:** Repodaki `static/logo.png`, `static/logo_koyu.png`,
   `static/logo.svg` dosyalarını bu paketteki aynı adlı dosyalarla değiştir.
   `static/logo_mark.svg`, `static/logo_mark.png`, `static/pwa_icon.png` yeni eklenir.
2. **⚠ Yerel dosya override'ı:** `app.py`'deki `/logo` endpoint'i şu tercih sırasını
   kullanır (eski `static/logo.svg` içindeki yoruma göre):
   `~/OneDrive/Masaüstü/LOGO_COFLE ONLY.png` → `~/Desktop/LOGO_COFLE ONLY.png` →
   `static/logo.png` → `static/logo.svg`.
   Sunucuda bu masaüstü PNG'leri varsa **eski logo servis edilmeye devam eder** —
   ya o dosyaları yenisiyle değiştir ya da `app.py`'de bu override yollarını kaldır.
3. **Tema parametresi:** `/logo?tema=koyu` → `logo_koyu.png` dönmeli (mevcut davranış
   korunur; sadece dosyalar yenilendi). `templates/panel_giris.html` ve
   `templates/rapor.html` bu parametreyi kullanıyor.
4. **Marka adı:** Görünen "Cofle Manage" metinlerini "Cofle Forge" yap
   (`grep -rn "Cofle Manage" templates/ app.py mail_raporu.py`):
   - `templates/panel_giris.html` — `<title>`, `<h1>`, © satırı
   - `templates/dashboard*.html` — `.sidebar-logo h2/p`
   - `templates/rapor.html`, `templates/mobile*.html`, `templates/andon*.html` başlıkları
   - E-posta raporu başlıkları (`mail_raporu.py`), sayfa `<title>`'ları (`app.py`)
   Veritabanı/tablo adlarına, route'lara ve config anahtarlarına DOKUNMA — sadece görünen metin.
5. **Favicon:** `panel_giris.html` `<link rel="icon" href="/logo">` kullanıyor; lockup yerine
   sembolü vermek için `/logo?tip=mark` gibi bir parametreyle `logo_mark.png` servis et
   ve icon linkini ona çevir (isteğe bağlı ama önerilir — sekmede lockup ezik görünür).
6. **PWA:** `static/sw.js` ve varsa manifest ikonlarını `pwa_icon.png` ile güncelle.
7. **Operatör uygulaması (mobile):** `templates/mobile.html` / `mobile_v2.html` de `/logo`
   yüklediği için otomatik yenilenir; ekstra iş yok. Andon ekranlarında logo koyu lacivert
   zeminde durur — `logo_koyu.png` doğru varyanttır.

## Design Tokens
- Gradyan: `#7C3AED → #A78BFA` (sol-alt → sağ-üst, 135°)
- Veri düğümü: koyu zeminde `#A78BFA`, açık zeminde `#7C3AED`
- Wordmark: Archivo — COFLE 700 (letter-spacing −1.4%), FORGE 300; koyu zeminde `#F7F7FB`, açık zeminde `#14122B`
- Uygulama arayüz fontu değişmez (Segoe UI stack); Archivo yalnız logo görsellerinde
- Zemin uyumu: uygulama tokenları `--bg #060414`, `--card #14122E`, `--primary #8B5CF6` ile test edildi

## Mark geometrisi (vektör, viewBox 0 0 64 64)
```
plaka üst:  M14 8 L44 8 L50 14 L50 19 L14 19 Z
plaka orta: M14 21 L25 21 L25 36 L14 36 Z
plaka alt:  M14 38 L25 38 L25 50 L19 56 L14 56 Z
atış:       M24 31 L29 31 L32 24 L35 38 L38 31 L43 31  (stroke 4.2, miter 2)
düğüm:      circle cx48 cy31 r3.2
```

## Files
- `Logo Export.dc.html` — PNG'lerin üretildiği sahne (referans)
- `static/*` — repoya kopyalanacak asset'ler
- Kök projede: `Cofle Forge Logo.dc.html` (seçilen kimlik sayfası, tüm lockup varyantları)
